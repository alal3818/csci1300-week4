#include <iostream>
using namespace std;

int main ( ) {
    int flute; // Woodwind
                    // Brass 
                    // Precussion

return 0;
}